# -*- coding: utf-8 -*-
"""
Created on Thu Jan  1 14:54:58 2020
@author: pascal winter

Bits and bolts for simple machine learning

1/ DATA EXPLORATION
2/ UNIVARIATE GRAPHING
3/ MULTIVARIATE GRAPHING
5/ GRID SEARCH (Model parametrization)
6/ MODEL ASSESSMENT
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns


from pathlib import Path
CWD = Path.cwd()


################################################################################
######################### DATA EXPLORATION #####################################
################################################################################
def data_describe(df_data):
    """
    Add further description to describe
    Plot a heatmap with Null values
    """
    # ------------- Calculate a Basic Description  --------------------------------#
    df_des = pd.DataFrame(index=df_data.columns)
    df_des['dtypes'] = df_data.dtypes
    df_des['nunique'] = df_data.nunique()
    df_des['isnull'] = df_data.isnull().sum()
    df_des['null_pc'] = df_des['isnull'] / df_data.shape[0] 
    # link with describe file
    dF_dummy = df_data.describe().transpose()
    df_des = pd.merge(df_des, dF_dummy, how ='left', left_index=True, right_index=True)
    # Produce a Is Na heatmap
    # Video on youtube
    plt.figure(3)
    sns.heatmap(df_data.isnull(), cbar=False, cmap='viridis')
    return df_des


def data_classvars(df_des):
    """
    Propose a variable classification based on a dF describe from above function
    """
    cond_a = df_des['mean'].isnull() == False
    cond_b = df_des['nunique'] < 20 # cutoff at for object vs cat
    df_des.loc[cond_a & ~cond_b, 'Type'] = 'Num'
    df_des.loc[cond_a & cond_b, 'Type'] = 'Cat'
    df_des.loc[~cond_a & ~cond_b, 'Type'] = 'Object'
    df_des.loc[~cond_a & cond_b, 'Type'] = 'Cat'
    # edit the lists
    list_numvar = list(df_des.loc[df_des['Type'] == 'Num'].index)
    list_catvar = list(df_des.loc[df_des['Type'] == 'Cat'].index)
    return list_numvar, list_catvar


################################################################################
######################### UNIVARIATE GRAPHING ##################################
################################################################################

# ------------------------ Univariate Graphing --------------------------------#
def graph_univar(df_data, list_numvar, list_catvar):
    """
    Graph very simple univariate for each variable
    NumVar: Histogram
    Catvar: BarPlot based on Count
    """
    # Histograms for Numerical variable
    for i, item in enumerate(list_numvar):
        cond_a = df_data[item].isna() == False
        dF_dummy = df_data.loc[cond_a]
        plt.figure(i)
        sns.distplot(dF_dummy[item])
    # Catplots for Cat variable
    for i, item in enumerate(list_catvar):
        cond_a = df_data[item].isna() == False
        dF_dummy = df_data.loc[cond_a]
        plt.figure(i) 
        sns.catplot(x=item, kind="count", data=dF_dummy)
    return


# --------------- Univariate Graphing with prediction -------------------------#
def graph_univar_pred(df_data, col_predict , list_numvar, list_catvar):
    """
    Graph very simple univariate for each variable compared with prediction (label in dF)
    NumVar: Violin Chart
    CatVar: Barplot count
    """
    # Histograms for Numerical variable
    for i, item in enumerate(list_numvar):
        cond_a = df_data[item].isna() == False
        cond_b = df_data[col_predict] != np.nan
        dF_dummy = df_data.loc[cond_a & cond_b]    
        plt.figure(i)
        sns.catplot(x=col_predict, y=item, kind='violin', data=dF_dummy)
    # Catplots for Cat with prediction
    for i, item in enumerate(list_catvar):
        cond_a = df_data[item].isna() == False
        cond_b = df_data[col_predict].isna() == False
        dF_dummy = df_data.loc[cond_a & cond_b]    
        plt.figure(i) 
        sns.catplot(x=item, hue=col_predict, kind='count', data=dF_dummy)
    return



################################################################################
######################### MULTIVARIATE GRAPHING ################################
################################################################################
# ----------------------------------- CAT with Num ----------------------------#
def graph_multvar_numcat(df_data, list_numvar, list_catvar):
    """
    Graph  simple bivariate Num with cat
    NumVar: Violin Chart
    CatVar: Barplot count
    """
    for i_num, item_num in enumerate(list_numvar):
        for i_cat, item_cat in enumerate(list_catvar):
            if item_cat != item_num:
                cond_a = df_data[item_num].isna() == False
                cond_b = df_data[item_cat].isna() == False
                dF_dummy = df_data.loc[cond_a & cond_b]
                plt.figure(i_cat) 
                #sns.catplot(x=item_cat, y=item_num, data=dF_dummy)
                #sns.catplot(x=item_cat, y=item_num, data=dF_dummy, kind='violin')
                sns.catplot(x=item_cat, y=item_num, data=dF_dummy, kind='boxen')
    return

# ----------------------------------- Num with Num ----------------------------#
def graph_multvar_numnum(df_data, list_numvar):
    """
    Graph  simple bivariate Num with Num
    Scatter Plot
    """
    for i_num, item_num in enumerate(list_numvar):
        for i_num2, item_num2 in enumerate(list_numvar):
            if i_num != i_num2:
                cond_a = df_data[item_num].isna() == False
                cond_b = df_data[item_num2].isna() == False
                dF_dummy = df_data.loc[cond_a & cond_b]
                plt.figure(i_num) 
                sns.relplot(x=item_num, y=item_num2, data=dF_dummy)
    return

# ----------------------------------- CAT with CAT ----------------------------#
def graph_multvar_catcat(df_data, list_catvar):
    """
    Graph  simple bivariate Cat with Cat
    Using Balloon Chart
    """
    for i_cat, item_cat in enumerate(list_catvar):
        for i_cat2, item_cat2 in enumerate(list_catvar):
            if i_cat < i_cat2:
                cond_a = df_data[item_cat].isna() == False
                cond_b = df_data[item_cat2].isna() == False
                dF_dummy = df_data.loc[cond_a & cond_b]
                plt.figure(i_cat)
                #sns.catplot(x=item_cat2, hue=item_cat, kind='count', data=dF_dummy)
                graph_balloon(dF_dummy,item_cat2,item_cat)
    return


# ------------------------ Baloon graph for multi cat -------------------------#
def graph_balloon(dF, x, y):
    """
    Prepare balloon chart with dF[x, y]
    
    """
    dF_data = dF.groupby([x,y])[y].count()
    dF_data = dF_data.rename("value")
    dF_data = dF_data.reset_index()
    # -------- Create the mapping dictionary for the x and y axis -------------#
    if pd.api.types.is_categorical_dtype(dF[x]) == True:
       xax_dict = dict(enumerate(dF[x].cat.categories))
    else:
       xax_dict = dict(enumerate(dF[x].unique()))
    if pd.api.types.is_categorical_dtype(dF[y]) == True:
       yax_dict = dict(enumerate(dF[y].cat.categories))
    else:
       yax_dict = dict(enumerate(dF[y].unique()))
    # -------------------------- Invert dict ----------------------------------#
    xax_dict = {v: k for k, v in xax_dict.items()}
    yax_dict = {v: k for k, v in yax_dict.items()}
    # --------------------------- Map the data --------------------------------#
    dF_data[x + '_'] = dF_data[x].map(xax_dict)
    dF_data[y +'_'] = dF_data[y].map(yax_dict)
    
    # -------------------------------- Graph ----------------------------------#
    fig, ax = plt.subplots()
    sns.scatterplot(x=x + '_', y=y +'_', size='value', data=dF_data
                , sizes=(20, 1000), hue='value')
                #, legend="full")
    ax.set_xlim(-1, len(xax_dict))
    ax.set_ylim(-1, len(yax_dict))
    ax.set_xticks(np.arange(len(xax_dict)))
    ax.set_yticks(np.arange(len(yax_dict)))
    ax.set_xticklabels(xax_dict.keys())
    ax.set_yticklabels(yax_dict.keys())
    return fig






################################################################################
######################### FEATURE ENGINEER #####################################
################################################################################

# calculating number of bins with that paper........
# NOT VALIDATED YET
# https://stats.stackexchange.com/questions/197499/what-is-the-best-way-to-decide-bin-size-for-computing-entropy-or-mutual-informat
def calc_bin_size(N):
    ee = np.cbrt(8 + 324*N + 12*np.sqrt(36*N + 729*N**2))
    bins = np.round(ee/6 + 2/(3*ee) + 1/3)
    return int(bins)






################################################################################
############################# GRID SEARCH ######################################
################################################################################


# from sklearn.model_selection import GridSearchCV

# ###############  RANDOM GRid Search for Random Forest 
# parameters = {'max_features': np.arange(5, 10), 'n_estimators':[500], 'min_samples_leaf':[10, 50, 100, 200, 500]}
# random_grid = GridSearchCV(models[1], parameters, cv = 5, verbose=10)
# random_grid.fit(X_train,y_train)
# a = random_grid.cv_results_
# a = random_grid.best_estimator_ 
# a = random_grid.best_params_


# ################  RANDOM GRid Search for Logit 
# parameters = {"C":np.logspace(-3,3,7), "penalty":["l1","l2"]} # l1 lasso l2 ridge
# random_grid = GridSearchCV(models[0], parameters, cv=10, verbose=10)
# random_grid.fit(X_train,y_train)
# a = random_grid.best_params_


# ###############  RANDOM GRid Search for GradientBoosting
# parameters = {
#     "loss":["deviance"],
#     "learning_rate": [0.01, 0.025, 0.05, 0.075, 0.1, 0.15, 0.2],
#     "min_samples_split": np.linspace(0.1, 0.5, 12),
#     "min_samples_leaf": np.linspace(0.1, 0.5, 12),
#     "max_depth":[3,5,8],
#     "max_features":["log2","sqrt"],
#     "criterion": ["friedman_mse",  "mae"],
#     "subsample":[0.5, 0.618, 0.8, 0.85, 0.9, 0.95, 1.0],
#     "n_estimators":[10]
#     }
# parameters = {'learning_rate': [0.1, 0.05, 0.02, 0.01],
#               'max_depth': [4, 6, 8],
#               'min_samples_leaf': [20, 50, 100,150],
#               'max_features': [1.0, 0.3, 0.1] 
#               }
# random_grid = GridSearchCV(models[2], parameters, cv=10, verbose=3)
# random_grid.fit(X_train,y_train)
# a = random_grid.best_params_









################################################################################
######################### MODEL ASSESSMENT #####################################
################################################################################

def model_assessment(classifiers, models, X, y, nsplit):
    """
    Assess a series of model with several sim and Provide a Boxplot of dsitrib results
    -------------
    classifiers = ['Logistic Regression','Random Forest','GradientBoosting']
    models = [LogisticRegression(),RandomForestClassifier(n_estimators=100),GradientBoostingClassifier(n_estimators=7,learning_rate=1.1)]
    X: full data predictors
    y: full data target
    nsplit: number of split 
    -----------------
    """
    from sklearn.model_selection import KFold #for K-fold cross validation
    from sklearn.model_selection import cross_val_score #score evaluation
    from sklearn.model_selection import cross_val_predict #prediction
    from sklearn import svm #support vector Machine
    kfold = KFold(n_splits=nsplit, random_state=22) # k=10, split the data into 10 equal parts
    lMean = []
    nAAccuracy = []
    lStdev = [] 
    for i in models:
        model = i
        cv_result = cross_val_score(model, X, y, cv=kfold, scoring="accuracy")
        lMean.append(cv_result.mean())
        lStdev.append(cv_result.std())
        nAAccuracy.append(cv_result)
    df_Res = pd.DataFrame({'CV Mean':lMean,'Std':lStdev}, index=classifiers)
    df_Acc = pd.DataFrame(nAAccuracy, index=classifiers)
    plt.figure(0)
    sns.catplot(kind='box', data=df_Acc.T)
    return df_Res, df_Acc

