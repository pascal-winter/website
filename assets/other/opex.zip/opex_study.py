# -*- coding: utf-8 -*-
import pandas as pd
import numpy as np
from pathlib import Path

CWD = Path('__file__').parent

"""

@author: wiloo82

This module is used to generate a fake portfolio to illustrate
the calculation of OPEX allocation

1/ Develop a Dataframe
 

"""
################################################################################
###################### PARAMETERS / INITIALISE #################################
################################################################################
# ------------------------------ Initialise  ----------------------------------#
csv_mp_outputname = 'OPEX_Allocated.csv'
dF_Test = pd.DataFrame(columns=['Test', 'Val1', 'Val2'])


# ------------------------------ Create Base OPEX -----------------------------#
# Define Centers and Nature List
centerlist = ['MilleniumFallout','DroidFleet','Contractors','Supplies','Transportation','Other']
naturelist = ['Defense','Prospection','Logistic','Extraction','Maintenance','Relation']
# develop dataframe with cartesian product
dF_BaseCost = pd.DataFrame(centerlist, columns=['Center'])
dF_Dummy = pd.DataFrame(naturelist, columns=['Nature'])
dF_BaseCost = dF_BaseCost.assign(key=1).merge(dF_Dummy.assign(key=1), on='key').drop('key', 1)
# Assign Random Values
np.random.seed(0) # seed to be able to reproduce
dF_BaseCost['Amount'] = np.random.normal(loc = 10000, scale=2000, size=dF_BaseCost.shape[0])
# Set different values by Center
dF_BaseCost.loc[dF_BaseCost['Center'] == 'MilleniumFallout','Amount'] *= 5
dF_BaseCost.loc[dF_BaseCost['Center'] == 'DroidFleet','Amount'] *= 10
dF_BaseCost.loc[dF_BaseCost['Center'] == 'Contractors','Amount'] *= 2
dF_BaseCost.loc[dF_BaseCost['Center'] == 'Supplies','Amount'] *= 1
dF_BaseCost.loc[dF_BaseCost['Center'] == 'Transportation','Amount'] *= 1
dF_BaseCost.loc[dF_BaseCost['Center'] == 'Other','Amount'] *= 1
# Set different values Nature
dF_BaseCost.loc[dF_BaseCost['Nature'] == 'Defense','Amount'] *= 2
dF_BaseCost.loc[dF_BaseCost['Nature'] == 'Prospection','Amount'] *= 5
dF_BaseCost.loc[dF_BaseCost['Nature'] == 'Logistic','Amount'] *= 3
dF_BaseCost.loc[dF_BaseCost['Nature'] == 'Extraction','Amount'] *= 10
dF_BaseCost.loc[dF_BaseCost['Nature'] == 'Maintenance','Amount'] *= 5
dF_BaseCost.loc[dF_BaseCost['Nature'] == 'Relation','Amount'] *= 3



# ---------------------------- Create Asteroid list ---------------------------#
# Define Asteroid List
asteroidlist = ['Enigma','Europa','Genosis','Tarsis','Altoria']
dF_Asteroid = pd.DataFrame(asteroidlist, columns=['Asteroid'])
# Assign Random Values
np.random.seed(0) # seed to be able to reproduce
dF_Asteroid['noDroids'] = np.random.random(size=dF_Asteroid.shape[0]) * 1000
dF_Asteroid['Extracted'] = np.random.random(size=dF_Asteroid.shape[0]) * 100000



 
################################################################################
################################### ALLOCATION #################################
################################################################################

#--------------------------- Develop Target Dataframe -------------------------#
dF_BaseCost2 = dF_BaseCost.assign(key=1).merge(dF_Asteroid.assign(key=1), on='key').drop('key', 1)

#--------------------------- Calculate the allocation key ---------------------#
dF_BaseCost2['key1'] = dF_BaseCost2['noDroids'] 
dF_Dummy = dF_BaseCost2.groupby(['Center','Nature'])['key1'].sum().rename('key1sum')
dF_BaseCost3 = dF_BaseCost2.merge(dF_Dummy, how='left', left_on=['Center','Nature'],
                                 right_index =True)#.reset_index()
#--------------------------- Calculate the amount -----------------------------#
dF_BaseCost3['Amount'] = dF_BaseCost3['Amount'] * dF_BaseCost3['key1']
dF_BaseCost3['Amount'] = dF_BaseCost3['Amount'] / dF_BaseCost3['key1sum']






################################################################################
###################### END - TEST & EXPORT #####################################
################################################################################
# ---------------------------------- Export  ----------------------------------#
spath = CWD.parent.as_posix() + "/" + csv_mp_outputname
dF_BaseCost.to_csv(spath, index = False) #, date_format='%Y%m%d')



#a = dF_BaseCost3.head(15).to_html(notebook = True, float_format='{:,.0f}'.format ).replace('\n','')
#b = dF_Asteroid.head(15).to_html(notebook = True, float_format='{:,.0f}'.format ).replace('\n','')




# ---------------------------------- Final Test  ------------------------------#
#dF_Test['Diff'] = dF_Test['Val1'] - dF_Test['Val2']
#dF_Test['Result'] = abs(dF_Test['Diff']) > 0.000001
#print(dF_Test)


